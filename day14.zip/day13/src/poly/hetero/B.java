package poly.hetero;

public class B {

}
