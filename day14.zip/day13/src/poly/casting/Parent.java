package poly.casting;

public class Parent {

	public void method1() {
		System.out.println("부모측 1번메서드 호출!");
	}
	
	public void method2() {
		System.out.println("부모측 2번메서드 호출!");
	}
}
