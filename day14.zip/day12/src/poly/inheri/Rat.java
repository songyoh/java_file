package poly.inheri;

public class Rat extends Monster {
	
	public Rat() {
		// 이름, 체력, 공격력, 방어력, 경험치
		super("쥐", 5, 1, 0, 80);
	}

}
