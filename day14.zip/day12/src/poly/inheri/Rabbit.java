package poly.inheri;

// Monster타입으로도 받을 수 있음.
public class Rabbit extends Monster {

	public Rabbit() {
		// 이름, 체력, 공격력, 방어력, 경험치
		super("토끼", 3, 0, 0, 5);
	}

}
