package poly.noinheri;

// 전사 단독으로 활용하는 경우
public class MainClass1 {
	
	public static void main(String[] args) {
		/*
		// 전사를 하나 생성해보자.
		Warrior	w1 = new Warrior("자바몬");	
		//w1.exp1 = 10000; private는 파일이 다르면 접근 불가
		
		// 생성 직후 정보 조회
		w1.showStatus();
		// 토끼 사냥
		w1.huntRabbit();
		// 정보 조회
		w1.showStatus();
		// 쥐 사냥
		w1.huntRat();
		// 정보 조회
		w1.showStatus();
		*/
	}

}
