package poly2.noinheri;

public class MainClass1 {

	public static void main(String[] args) {
		//Warrior w1 = new Warrior("자바몬");
		
		//w1.showStatus();
		
		//w1.huntRabbit();
		
		//w1.showStatus();
		
		//w1.huntRat();
		
		//w1.showStatus();

	}

}
