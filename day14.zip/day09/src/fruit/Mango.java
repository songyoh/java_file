package fruit;


public class Mango {

}
