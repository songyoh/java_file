package hello;

public class Hello {

}
