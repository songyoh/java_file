package hello.hi;


public class Hi {

}
