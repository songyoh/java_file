package strequals;

public class User {
	String id;
	String pw;
	
	public User(String upw) {// 생성자
		pw = upw;
	}// 생성자
}
