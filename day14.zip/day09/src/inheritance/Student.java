package inheritance;

public class Student extends Human {// 상속 문법(extends뒤에 물려받고싶은 클래스명을 적는다.)
	
	public String major;

}
