package inheritance;

public class Human {
	// 사람이라면 가져야 하는 특성을 기술합니다.
	public String name;
	public int age;


}
