package inheritance;

public class Salaryman extends Human {
	
	int salary;

}
