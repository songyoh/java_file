package example.modi.protec.pac1;

public class B {

	public B() {
		A a = new A();
		a.s = "hi";
		a.method();
	}
}
