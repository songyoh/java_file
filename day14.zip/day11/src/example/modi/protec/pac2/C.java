package example.modi.protec.pac2;

// import  패키지 구조 protec인지 꼭 확인!
import example.modi.protec.pac1.A;

public class C {

	public C() {
		//A a = new A();
		//a.s = "hihihihi!";
		//a.method1();
	}
	
}
