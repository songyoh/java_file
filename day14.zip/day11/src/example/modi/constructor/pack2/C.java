package example.modi.constructor.pack2;

import example.modi.constructor.pack1.A;

public class C {
	// 여러분들이 A를 호출해보세요.
	
	// public 생성자
	 A a1 = new A(true);
	// default 생성자 // 없는게 아니라 조회불가능 // 패키지가 다르기 때문
	 // A a2 = new A(100);
	// private 생성자는 조회 불가
	 // A a3 = new A("김자바");
	
}
