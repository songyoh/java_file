module chap10 {
	requires java.se;	
}