module chap03 {
	requires java.se;
}