package sec01.exam10;

public class Car {
	
}
