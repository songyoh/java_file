package sec01.exam01;

public class APIDocument {
	public static void main(String[] args) {
		String str = "���ڹ�";
	}
}
