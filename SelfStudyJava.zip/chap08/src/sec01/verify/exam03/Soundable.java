package sec01.verify.exam03;

public interface Soundable {
	String sound();
}
