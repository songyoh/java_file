package sec02.exam02;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
