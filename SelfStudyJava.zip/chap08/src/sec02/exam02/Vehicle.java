package sec02.exam02;

public interface Vehicle {
	public void run();
}
