package sec02.exam05;

public interface InterfaceA {
	public void methodA();
}

