package sec02.verify.exam03;

public class Member {
	String name;
	String id;
	String password;
	int age;
}
