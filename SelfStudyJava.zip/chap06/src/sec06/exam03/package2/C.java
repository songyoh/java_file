package sec06.exam03.package2;

import sec06.exam03.package1.*;

public class C {
	//A a;
	B b;
}

