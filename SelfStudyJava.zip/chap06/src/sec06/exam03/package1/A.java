package sec06.exam03.package1;

class A {

}
