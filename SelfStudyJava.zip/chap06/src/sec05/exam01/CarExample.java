package sec05.exam01;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car("������");
		Car yourCar = new Car("����");
		
		myCar.run();
		yourCar.run();
	}
}
