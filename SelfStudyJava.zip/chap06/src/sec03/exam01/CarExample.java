package sec03.exam01;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car("����", 3000);
		//Car myCar = new Car();  (x)
	}
}
