package sec03.exam02;

public class ProductStorageExample {
	public static void main(String[] args) {
		ProductStorage productStoreage = new ProductStorage();
		productStoreage.showMenu();
	}
}
