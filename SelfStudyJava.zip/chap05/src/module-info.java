module chap05 {
	requires java.se;
}