package sec02.exam01;

public class B extends A {

}
