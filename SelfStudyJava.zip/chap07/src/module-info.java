module chap07 {
	requires java.se;
}