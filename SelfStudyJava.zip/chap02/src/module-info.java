module chap02 {
	requires java.se;
}