
public class IdentifierExample2 {

	public static void main(String[] args) {
		
		int money = 10000;
		int salary = 6600000;
		
		System.out.println(money + salary);

	}

}
