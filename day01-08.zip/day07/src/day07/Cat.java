package day07;

public class Cat { //설계도
	// 클래스 생성시 지금은 변수옆에 public 꼭 붙이기
	public String name;  //고양이 이름
	public String kind; //고양이 품종
	public int age; // 고양이 나이
	public String color; //고양이 털색깔	
}
