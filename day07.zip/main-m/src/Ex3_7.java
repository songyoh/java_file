
public class Ex3_7 {

	public static void main(String[] args) {
		System.out.println(5/2);
		System.out.println(5/ (float)2);

	}

}
