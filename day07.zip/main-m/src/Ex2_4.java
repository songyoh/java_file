
public class Ex2_4 {

	public static void main(String[] args) {
		int x = 5;
		System.out.println(x);
		
		x = 10;
		System.out.println(x);
			

	}

}
