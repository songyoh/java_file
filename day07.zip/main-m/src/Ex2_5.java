
public class Ex2_5 {

	public static void main(String[] args) {
		int x = 10;
		int y = 5;
		System.out.println(x+y);
		System.out.println(x-y);
		System.out.println(x*y);
		System.out.println(x/y);

	}

}
