
public class Ex2_1 {

	public static void main(String[] args) {
		System.out.println("Hello, world!");
		System.out.println(3+5);
		System.out.println("3+5=8");

	}

}
