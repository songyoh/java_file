
public class Ex4_1 {

	public static void main(String[] args) {
		int score = 80;
		
		if (score > 60)  
			System.out.println("합격입니다."); // {} 1건일 경우 중괄호 생략가능
		 
	}

}
